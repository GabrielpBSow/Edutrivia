<?php 
    $conexion = mysqli_connect(
        'localhost', 
        'root',
        '',
        'estancia'
    );
?>
<?php
    if(isset($conexion)){
       /* echo "CONEXIÓN EXITOSA"; */
    }else{
        echo "ERROR 400: NO HUBO CONEXIÓN";
    }       
?>