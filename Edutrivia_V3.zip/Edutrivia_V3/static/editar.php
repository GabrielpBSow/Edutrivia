<?php include '../bd/conexion.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="fondo">
    <?php 
        if(isset($_GET['id'])){
            $ID = $_GET['id'];
            $query = "SELECT * FROM Juego where id = $ID;";
            $result = mysqli_query($conexion, $query);
            if(mysqli_num_rows($result)==1){
                $row = mysqli_fetch_array($result);
                $Categoria = $row['Categoria'];
                $Pregunta = $row['Pregunta'];
                $Respuesta = $row['Respuesta'];
                $Puntaje = $row['Puntaje'];
            }
        }

        // ACTUALIZACION
        if(isset($_POST['editar'])){
            $id = $_GET['id'];
            $Categoria = $_POST['Categoria'];  // Actualizar con los nuevos valores del formulario
            $Pregunta = $_POST['Pregunta'];    // Actualizar con los nuevos valores del formulario
            $Respuesta = $_POST['Respuesta'];  // Actualizar con los nuevos valores del formulario
            $Puntaje = $_POST['Puntaje'];      // Actualizar con los nuevos valores del formulario

            $update = "UPDATE Juego SET Categoria  = '$Categoria', Pregunta = '$Pregunta', Respuesta = '$Respuesta', Puntaje = '$Puntaje' WHERE id = $id;";
            mysqli_query($conexion, $update);
            header("Location:../pages/read.php");
        }
    ?>
    <link rel="stylesheet" href="../css/editar.css">
    <br></br>
    <h1 class="editar-title">Actualizar</h1>

    <form method="POST" action="editar.php?id=<?php echo $_GET['id'];?>">
    <div class="form_container">
            <label for="Categoria">Categoría:</label>
            <input type="text" id=Categoria" name="Categoria" class="name_input"  value="<?php echo $Categoria ?>"><br><br>
        </div> 
        <div class="form_container">
            <label for="Pregunta">Pregunta:</label>
            <input type="text" id="Pregunta" name="Pregunta" class="name_input"  value="<?php echo $Pregunta ?>"><br><br>
        </div> 
        <div class="form_container">
            <label for="Respuesta">Respuesta:</label>
            <input type="text" id="Respuesta" name="Respuesta" class="name_input"  value="<?php echo $Respuesta ?>"><br><br>
        </div> 
        <div class="form_container">
            <!--<label for="Puntaje">Puntaje:</label>
            <input type="text" id="Puntaje" name="Puntaje" class="name_input"  value="<?php echo $Puntaje ?>">-->
            <label for="Puntaje">Puntaje:</label>
            <select name="Puntaje" id="Puntaje">
                <option value="100">100</option>
                <option value="200">200</option>
                <option value="300">300</option>
                <option value="400">400</option>
                <option value="500">500</option>
            </select>
        </label>
            <br><br>
        </div> 
        
        <br>
        <div class="form_container">                    
        <input type="submit" value="Actualizar" name="editar" class="btn" onclick="return alertModificado()">
    </form>
    <script>
            function alertModificado() {
                return confirm("Modificado con Éxito!!");
            }
    </script>

</body>
</html>