<?php include '../bd/conexion.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
</head>
<body class="fondo">
    <?php 
        if(isset($_GET['id'])){
            $ID = $_GET['id'];
            $query = "SELECT * FROM registro where id = $ID;";
            $result = mysqli_query($conexion, $query);
            if(mysqli_num_rows($result)==1){
                $row = mysqli_fetch_array($result);
                $nombre = $row['nombre'];
                $correo = $row['correo'];
                $contraseña = $row['contraseña'];
                $rol = $row['rol'];
            }
        }

        // ACTUALIZACION
        if(isset($_POST['editar'])){
            $id = $_GET['id'];
            $nombre = $_POST['nombre'];  // Actualizar con los nuevos valores del formulario
            $correo = $_POST['correo'];    // Actualizar con los nuevos valores del formulario
            $contraseña = $_POST['contraseña'];  // Actualizar con los nuevos valores del formulario
            $rol = $_POST['rol'];      // Actualizar con los nuevos valores del formulario

            $update = "UPDATE registro SET nombre  = '$nombre', correo = '$correo', contraseña = '$contraseña', rol = '$rol' WHERE id = $id;";
            mysqli_query($conexion, $update);
            header("Location:../pages/VerUsuarios.php");
        }
    ?>
    <link rel="stylesheet" href="../css/editar.css">
    <br></br>

    <form method="POST" action="editar_U.php?id=<?php echo $_GET['id'];?>">
    <h1 class="create-title">Actualizar</h1>
    <div class="form_container">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" class="name_input"  value="<?php echo $nombre ?>"><br><br>
        </div> 
        <div class="form_container">
            <label for="correo">Correo:</label>
            <input type="text" id="correo" name="correo" class="name_input"  value="<?php echo $correo ?>"><br><br>
        </div> 
        <div class="form_container">
            <label for="contraseña">Contraseña:</label>
            <input type="text" id="contraseña" name="contraseña" class="name_input"  value="<?php echo $contraseña ?>"><br><br>
        </div> 
        <div class="form_container">
            <!--<label for="Puntaje">Puntaje:</label>
            <input type="text" id="Puntaje" name="Puntaje" class="name_input"  value="<?php echo $Puntaje ?>">-->
            <label for="rol">Rol:</label>
            <select name="rol" id="rol">
                <option value="Administrador">Administrador</option>
                <option value="Profesor">Profesor</option>
                <option value="Estudiante">Estudiante</option>
            </select>
        </label>
            <br><br>
        </div> 
        
        <br>
        <div class="form_container">                    
        <input type="submit" value="Actualizar" name="editar" class="btn" onclick="return alertModificado()">
    </form>
    <script>
            function alertModificado() {
                return confirm("Modificado con Éxito!!");
            }
    </script>

</body>
</html>