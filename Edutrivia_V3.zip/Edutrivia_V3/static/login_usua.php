<?php
include '../bd/conexion.php';

session_start();

    
if (isset($_POST['Email']) && isset($_POST['Contra'])) {
    $email = $_POST['Email'];
    $pass = $_POST['Contra'];
    $nom = $_POST['nombre'];

    // Buscar el usuario por su correo electrónico
    $query = "SELECT * FROM registro WHERE correo = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['contraseña'];

        // Verificar la contraseña
        if (password_verify($pass, $hashedPassword)) {
            // Verificar el rol del usuario
            $rol = $row['rol'];
             // Almacenar el rol en la variable de sesión
            $_SESSION['rol'] = $rol;
            // Redirigir según el rol del usuario
        switch ($rol) {
            case 'Administrador':
                // Almacena el nombre en la variable de sesión
                $_SESSION['usuario'] = $row['nombre']; //$email;
                echo '
                    <script>
                        alert("Bienvenido");
                        window.location = "../pages/admin_A.php";
                    </script>
                ';
                break;
            case 'Estudiante':
                // Almacena el nombre en la variable de sesión
                $_SESSION['usuario'] = $row['nombre']; //$email;
                echo '
                    <script>
                        alert("Bienvenido");
                        window.location = "../pages/admin_E.php";
                    </script>
                ';
                break;
            case 'Profesor':
                // Almacena el nombre en la variable de sesión
                    $_SESSION['usuario'] = $row['nombre']; //$email;
                    echo '
                        <script>
                            alert("Bienvenido");
                            window.location = "../pages/admin_P.php";
                        </script>
                    ';
                break;
            default:
                header("Location: ../Edutrivia_V2/principal.php");       
            }
            exit;
        } else {
            echo '
                <script>
                    alert("Contraseña incorrecta");
                    window.location = "../pages/registro.php";
                </script>
            ';
            exit;
        }
    } else {
        echo '
            <script>
                alert("Usuario no encontrado");
                window.location = "../pages/registro.php";
            </script>
        ';
        exit;
    }
} else {
    echo '
        <script>
            alert("DEBES LLENAR TODOS LOS CAMPOS");
            window.location = "../pages/registro.php";
        </script>
    ';
    exit;
}
?>
