<?php include '../bd/conexion.php'?>
<a href = "../pages/index.php"><img src="../img/before_writh.png"></a>
<br></br>
<?php 
    
    if(isset($_GET['id'])){
        $ID = $_GET['id'];
        echo '
            <script>
                alert("¿Seguro que quieres borrar?");
                window.location = "../pages/read.php";
            </script>
        ';
        $delete = "DELETE FROM Juego where id = $ID;";
        mysqli_query($conexion, $delete);
        sleep(1);
        header("Location:../pages/read.php");
    }
?>