<?php 
    include("../bd/conexion.php");
    if(isset($_POST['send1'])){
        if(
            strlen($_POST['Nombre'])>=1 &&
            strlen($_POST['Correo'])>=1 &&
            strlen($_POST['Contraseña'])>=1 &&
            isset($_POST['Rol'])
        ){
            $name = trim($_POST['Nombre']);
            $email = trim($_POST['Correo']);
            $pass = trim($_POST['Contraseña']);
            $rol = trim($_POST['Rol']);
             // Clave secreta para la encriptación de contraseñas (deberías almacenarla de forma segura)
            $secretKey = "clave_secreta";
            // Algoritmo de encriptación para las contraseñas (puedes usar bcrypt, por ejemplo)
            $hashedPassword = password_hash($pass, PASSWORD_BCRYPT);

            $query = "INSERT INTO registro (nombre, correo, contraseña, rol) VALUES ('$name', '$email', '$hashedPassword','$rol');";

            $execute = mysqli_query($conexion, $query);

            if ($execute) {
                ?>
                <h3 class="success">Registro exitoso</h3>
                <?php
                header("Location:../pages/admin_A.php");
            } else {
                echo '
                    <script>
                        alert("No se pudo realizar el registro");
                        window.location = "../pages/registro.php";
                    </script>
                ';
            }   
        }else{
            echo '
                <script>
                    alert("Debes llenar todos los campos");
                    window.location = "../pages/registro.php";
                </script>
            ';
        }
    }
?>