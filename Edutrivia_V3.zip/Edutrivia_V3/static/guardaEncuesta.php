<?php
    include '../bd/conexion.php';

    // Obtener la opción enviada desde el cliente
    $opcion = isset($_POST['opcion']) ? $_POST['opcion'] : 0;

    // Obtener la fecha y hora actual del servidor
    $fecha = date("Y-m-d H:i:s");

    // Insertar la opción y la fecha en la base de datos (reemplaza 'Encuesta_satis' con el nombre real de tu tabla)
    $sql = "INSERT INTO Encuesta_satis (opcion, fecha) VALUES ('$opcion', '$fecha')";

    if ($conexion->query($sql) === TRUE) {
        echo '
        <script>
            alert("ENCUESTA ENVIADA");
            window.location = "../pages/gracias.php";
        </script>
    ';
    } else {
        echo '
                <script>
                    alert("ERROR EN LA ENCUESTA");
                    window.location = "../pages/encuesta.php";
                </script>
            ';
    }
    
    // Cerrar la conexión
    $conexion->close();
?>

 
 
 
 
 
 //<?php 
 //   include '../bd/conexion.php';

 //   $opcion = isset($_POST['opcion']) ? $_POST['opcion']:1 ;
  //  $fecha = date("Y-m-d Hi");
 //   $sql = "INSERT INTO Encuesta_satis (opcion, fecha) VALUES ($opcion, $fecha)";

  /*  if ($conexion->query($sql) === TRUE) {
        echo '
        <script>
            alert("ENCUESTA ENVIADA");
            window.location = "../pages/gracias.php";
        </script>
    ';
    } else {
        echo '
                <script>
                    alert("ERROR EN LA ENCUESTA");
                    window.location = "../pages/encuesta.php";
                </script>
            ';
    }
    
    // Cerrar la conexión
    $conexion->close();
?>
// Obtener la opción enviada desde el cliente
$opcion = isset($_POST['opcion']) ? $_POST['opcion'] : 0;

// Insertar la opción en la base de datos (reemplaza 'nombre_de_tu_tabla' con el nombre real de tu tabla)
$sql = "INSERT INTO nombre_de_tu_tabla (opcion) VALUES ($opcion)";

if ($conn->query($sql) === TRUE) {
    echo "Encuesta guardada con éxito";
} else {
    echo "Error al guardar la encuesta: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>

include '../bd/conexion.php';

$opcion = isset($_POST['opcion']) ? $_POST['opcion'] : 1;
$fecha = date("Y-m-d Hi");
$sql = "INSERT INTO Encuesta_satis (opcion, fecha) VALUES ('$opcion', '$fecha')";

if ($conexion->query($sql) === TRUE) {
    echo '
   /* <script>
        alert("ENCUESTA ENVIADA");
        window.location = "../pages/gracias.php";
    </script>
';*/
/* } else {
    echo '
        <script>
            alert("ERROR EN LA ENCUESTA");
            window.location = "../pages/encuesta.php";
        </script>
    ';
} 

// Cerrar la conexión
$conexion->close(); */