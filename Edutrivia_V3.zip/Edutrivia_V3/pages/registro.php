<?php include '../bd/conexion.php';
session_start();

if(isset($_SESSION['usuario'])){
    header("Location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lora:wght@500&family=Montserrat+Alternates&family=Poppins&family=Roboto&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
    <link rel="stylesheet" href="../css/style.css">
    <title>Registro</title>
</head>
<body>
    <div class="container-form register">
        <div class="information">
            <div class="info-childs">
                <h2>¡¡Bienvenido!!</h2>
                <p> Si ya tienes una cuenta, ¡Pulsa Aquí!</p>
                <input type="button" value="iniciar Sesión" id="sign-in">
            </div>
        </div>
        <!--FORMULARIO DE REGISTRO -->
        <div class="form-information">
            <div class="form-information-childs">
                <h2>Crear una Cuenta</h2>
                <div class="icons">
                    <i class='bx bxl-google'></i>
                    <i class='bx bxl-github'></i>
                    <i class='bx bxl-microsoft'></i>
                </div>
                <p>Iniciar Sesion con Correo Electronico</p>
                <form class="form"  method="POST" name="frm1" id="frm1" autocomplete="off">
                  <div>
                    <label for="Nombre">
                        <i class='bx bx-user'></i>
                        <input type="text" name="Nombre" id="Nombre" placeholder="Nombre Completo"  maxlength="9">
                    </label>
                    <p class="alert alert-danger" style="display: none" id="nom">Ingresa un Nombre Valido!</p>
                  </div>
                    
                    <label for="Correo">
                        <i class='bx bx-envelope'></i>
                        <input type="email" name="Correo" id="Correo" placeholder="Correo electronico">
                    </label>
                    <label for="Contraseña">
                        <i class='bx bxs-lock'></i>
                        <input type="password" name="Contraseña" id="Contraseña" placeholder="Contraseña"  maxlength="8">
                    </label>
                    <label for="Rol">
                        <i class='bx bx-user'></i>
                        <select name="Rol" id="Rol">
                            <option value="Administrador">Administrador</option>
                            <option value="Estudiante">Estudiante</option>
                            <option value="Profesor">Profesor</option>
                        </select>
                    </label>
                    <input name="send1" type="submit" value="Registrar" onclick="validacion()">
                </form>
            </div>
        </div>
    </div>

<?php
    include("../static/sends.php")
?>

    <!--INICIO DE SESION, EL USUARIO DEBE DE ESTAR PREVIAMENTE REGISTRADO-->
    <div class="container-form login hide">
        <div class="information">
            <div class="info-childs">
                <h2>¡Qué Bueno Verte de Nuevo!</h2>
                <p> Si aún no tienes una cuenta, ¡Qué esperas,
                    Registrate aquí!
                </p>
                <input type="button" value="Registrarse" id="sign-up">
            </div>
        </div>
        <div class="form-information">
            <div class="form-information-childs">
                <h2>Iniciar Sesión</h2>
                <div class="icons">
                    <i class='bx bxl-google'></i>
                    <i class='bx bxl-github'></i>
                    <i class='bx bxl-microsoft'></i>
                </div>
                <p>Iniciar Sesion con Correo Electronico</p>


                <form class="form" method="POST" name="frm2" id="frm2" autocomplete="off" action="../static/login_usua.php">
                    <label>
                        <i class='bx bx-envelope'></i>
                        <input type="email" name="Email" id="email" placeholder="Correo electronico">
                    </label>
                    <label>
                        <i class='bx bxs-lock'></i>
                        <input type="password" name="Contra" id="pass" placeholder="Contraseña">
                    </label>
                    <label for="Rol">
                        <select name="Rol" id="Rol">
                            <option value="Administrador">Administrador</option>
                            <option value="Estudiante">Estudiante</option>
                            <option value="Profesor">Profesor</option>
                        </select>
                    </label>
                    <div>
                        <input type="submit" value="Iniciar Sesión" onclick="validacion()">
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
    <script src="../js/script.js"></script>
    <script src="../js/validaciones.js"></script>
</body>
</html>