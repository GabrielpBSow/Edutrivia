<?php
    // Datos de conexión a la base de datos
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $bd = 'estancia';

    // Nombre del archivo de respaldo
    $fecha = date("Ymd-His");
    $salida_sql = $bd.'_'.$fecha.'.sql';

    // Ruta al ejecutable mysqldump
    $mysqldumpPath = 'C:\wamp64\bin\mysql\mysql8.0.31\bin\mysqldump.exe'; // Ruta al ejecutable mysqldump en tu sistema

    // Comando para crear el respaldo
    $comando = "$mysqldumpPath -h$host -u$user -p$pass --opt $bd > $salida_sql";

    // Ejecutar el comando para generar el respaldo
    system($comando, $output);

    // Verificar si se generó correctamente
    if ($output === 0) {
        // Comprimir el archivo SQL en un archivo ZIP
        $salida_zip = $bd.'_'.$fecha.'.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($salida_zip, ZipArchive::CREATE) === true) {
            $zip->addFile($salida_sql, basename($salida_sql));
            $zip->close();
            unlink($salida_sql);

            // Descargar el archivo ZIP
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . basename($salida_zip) . '"');
            header('Content-Length: ' . filesize($salida_zip));
            readfile($salida_zip);
            unlink($salida_zip); // Eliminar el archivo ZIP después de la descarga

            exit; // Terminar la ejecución después de la descarga
        } else {
            echo 'Error al crear el archivo ZIP';
        }
    } else {
        echo 'Hubo un error al generar el respaldo.';
    }
?>




