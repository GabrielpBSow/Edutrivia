<!DOCTYPE html>
<html>
<head>
    <title>Reportes</title>
    <link rel="stylesheet" href="../css/index.css">
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
</head>
<body class="fondo">

    <header class="top">
        <h1>Reportes</h1>
    </header>

    <div class="menu-options">
        <lo>
            <ul><a href="Reporte_Encuesta.php">Encuestas de Satisacción</a></ul>
        </lo>
        <lo>
            <ul><a href="Reporte_Usuarios.php">Tipos de Usuarios</a></ul>
        </lo>
    </div>
</body>
</html>