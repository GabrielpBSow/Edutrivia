<?php include '../bd/conexion.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../Edutrivia/css/normalize.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
    <title>Usuarios</title>
</head>
<body  style="background-image: linear-gradient(180deg,#0000008c 0%, #0000008c 100%), url(../img/fondo_principal.jpg);">
    <h1 class="title_CPreguntas">Consulta de Usuarios</h1>
    </br>
    <table>
        <thread>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th>Eliminar</th>
                <th>Editar</th>
            </tr>
        </thread>
    <?php 
        $query = "SELECT * FROM registro;";
        $result = mysqli_query($conexion, $query);
            while($row = mysqli_fetch_array($result)){ ?>
                <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['nombre']?></td>
                    <td><?php echo $row['correo']?></td>
                    <td><?php echo $row['contraseña']?></td>
                    <td><?php echo $row['rol']?></td>
                    <td> 
                        <a href="../static/eliminar_U.php?id=<?php echo $row['id']?>" onclick="return confirmarBorrado()">
                        <img /*src="Static/img/tash1.png"*/><i class='bx bx-trash' style='color:#fffefe'></i>
                    </td>
                    <td> 
                        <a href="../static/editar_U.php?id=<?php echo $row['id']?>">
                        <img /*src="Static/img/refresh1.png"*/><i class='bx bx-revision' style='color:#fdf5f5'></i>
                    </td>
                    
                </tr>
    <?php   } ?>
    </table>

    <script>
        function confirmarBorrado() {
            return confirm("¿Seguro que quieres borrar?");
        }
    </script>
</body>
</html>