<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Static/css/jeopardy.css">
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
    <link rel="stylesheet" href="../Edutrivia_V2/css/normalize.css">
    <link rel="stylesheet" href="../css/pages.css">
    <title>Gestión de Usuarios</title>
</head>
<body class="fondo">
    <form method="POST" action="Gestion_Usuarios.php" id="gestionarUsuarios">
        <h1 class="create-title">Gestión de Usuarios</h1>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" class="name_input"><br><br>

        <label for="correo">Correo:</label>
        <input type="text" id="correo" name="correo" class="name_input"><br><br>

        <label for="contraseña">Contraseña:</label>
        <input type="password" id="contraseña" name="contraseña" class="name_input"><br><br>

        <label for="rol">
        <label for="rol">Rol:</label>
            <select name="rol" id="rol">
                <option value="Administrador">Administrador</option>
                <option value="Profesor">Profesor</option>
                <option value="Estudiante">Estudiante</option>
            </select>
        </label>

        <input type="submit" value="Guardar Usuario" class="btn">
    </form>
</body>
</html>
