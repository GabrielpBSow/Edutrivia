<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/Ahorcado.css">
    <title>Ahorcado</title>
  </head>
  <body>
    <div id="content-main">
      <h1>El juego del ahorcado</h1>
      <div id="ahorcado"></div>
      <p id="output"></p>
      <div>
        <input type="text" id="letra" maxlength="1" placeholder="Escribir aquí" autofocus/>
        <button id="calcular" >EVALUAR LETRA</button>
      </div>
      <h1 id="resultado"></h1>
    </div>

    <script>
      String.prototype.replaceAt = function(index, character) {
        return this.substring(0, index) + character + this.substring(index + character.length);
      };

      fetch('Obtener_Palabras.php')
        .then(response => response.json())
        .then(data => {
          const categorias = data.categorias;

          const categoria = categorias[Math.floor(Math.random() * categorias.length)];
          let palabraConGuiones = '';

          for (let i = 0; i < categoria.length; i++) {
            if (categoria[i] === ' ') {
              palabraConGuiones += '  '; // Si es un espacio, agrega dos espacios
            } else {
              palabraConGuiones += '_ '; // Agrega un guion bajo seguido de un espacio
            }
          }

          let contadorFallos = 0;

          document.querySelector('#output').innerHTML = palabraConGuiones;

          const palabraCorrecta = categoria.toLowerCase(); // Almacena la palabra correcta en minúsculas

          const button = document.querySelector('#calcular');
          const ahorcadoDiv = document.getElementById('ahorcado');

          button.addEventListener('click', () => {
            let letra = document.querySelector('#letra').value.toLowerCase();

            let haFallado = true;

            let letraCorrecta = false;
            for (let i = 0; i < palabraCorrecta.length; i++) {
              if (letra === palabraCorrecta[i]) {
                palabraConGuiones = palabraConGuiones.replaceAt(i * 2, letra); // * 2 para ajustar espacios
                haFallado = false;
                letraCorrecta = true;
              }
            }

            if (!letraCorrecta) {
              contadorFallos++;
              if (contadorFallos === 6) {
                alert('¡Has Perdido :(!');
                window.location.href = 'encuesta.php';
              } else {
                // Cambiar la imagen del ahorcado
                ahorcadoDiv.innerHTML = `<img src="../img/el-ahorcado${contadorFallos}.jpg" alt="Ahorcado" />`;
              }
            }

            if (!palabraConGuiones.includes('_')) {
              alert('¡Has Ganado :D!');
              window.location.href = 'encuesta.php';
            }

            document.querySelector('#output').innerHTML = palabraConGuiones;
          });
        })
        .catch(error => {
          console.error('Error al obtener palabras:', error);
        });
    </script>
  </body>
</html>