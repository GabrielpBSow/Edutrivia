<?php include '../bd/conexion.php'?>
<?php

    if (!$conexion) {
        die("La conexión falló: " . mysqli_connect_error());
    }

    $sql = "SELECT Categoria, Pregunta, Respuesta, Puntaje FROM (
        SELECT *,  ROW_NUMBER() OVER (PARTITION BY Categoria ORDER BY Puntaje DESC) 
        as Categorias FROM Juego) as Rango WHERE Categorias <= 5 ORDER BY Categoria, Puntaje DESC";
    
    $result = mysqli_query($conexion, $sql);

    if ($result) {
        
        $preguntas = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $pregunta = array(
                'Categoria' => $row['Categoria'],
                'Pregunta' => $row['Pregunta'],
                'Respuesta' => $row['Respuesta'],
                'Puntaje' => $row['Puntaje']
            );
            $preguntas[] = $pregunta;
        }
        echo json_encode($preguntas);
    } else {
        echo "0 resultados";
    }

    mysqli_close($conexion);
?>
