<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/encuesta.css"> 
    <title>Encuesta de Satisfacción</title>
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
</head>
<body>
    <h2>¿Te gustó el juego?</h2>
    <form id="encuestaForm" method="POST" action="../static/guardaEncuesta.php">
        <div class="options" >
            <div class="option" onclick="selectOption(1)">
                <img src="../img/Excelente.png" alt="Excelente" width="50" height="50" name="Excelente">
                <p>Excelente</p>
            </div>
            <div class="option" onclick="selectOption(2)">
                <img src="../img/Bueno2.png" alt="Bueno" width="50" height="50" name="Bueno">
                <p>Bueno</p>
            </div>
            <div class="option" onclick="selectOption(3)">
                <img src="../img/Regular.png" alt="Regular" width="50" height="50" name="Regular">
                <p>Regular</p>
            </div>
            <div class="option" onclick="selectOption(4)">
                <img src="../img/Malo2.png" alt="Malo" width="50" height="50" name="Malo">
                <p>Malo</p>
            </div>
        </div>
        <input type="hidden" name="opcion" id="opcionSeleccionada">
        <button id="submitBtn">Enviar</button>
    </form>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../js/encuesta.js"></script>
    <script>
        function selectOption(opcion) {
            document.getElementById('opcionSeleccionada').value = opcion;
        }

        document.getElementById('submitBtn').addEventListener('click', function(event) {
            event.preventDefault(); 
            document.getElementById('encuestaForm').submit(); 
        });
    </script>
</body>
</html>
