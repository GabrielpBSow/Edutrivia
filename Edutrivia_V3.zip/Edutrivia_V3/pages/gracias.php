<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gracias</title>
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
</head>
<body>
        <center><h1>GRACIAS POR TU VOTO</h1></center>
        <center><h3>Sigue aprendiento mientras juegas</h3></center>
        <center><a><img src="../img/like.png"></a></center>
</body>
</html>