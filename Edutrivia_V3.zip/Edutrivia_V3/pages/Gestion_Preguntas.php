<?php include '../bd/conexion.php'?>
<?php
    $categoria = $_POST['categoria'];
    $pregunta = $_POST['pregunta'];
    $respuesta = $_POST['respuesta'];
    $puntaje = $_POST['puntaje'];

    $query = "INSERT INTO Juego (Categoria, Pregunta, Respuesta, Puntaje) VALUES ('$categoria', '$pregunta', '$respuesta', $puntaje);";

    $execute = mysqli_query($conexion, $query);

    sleep(1);
    header("Location: create.php");
    

?>
