<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="Static/css/jeopardy.css">
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
    <link rel="stylesheet" href="../Edutrivia_V2/css/normalize.css">
     <link rel="stylesheet" href="../css/pages.css">
    
   </head>
<body class="fondo">

    
    <form method="POST" action="Gestion_Preguntas.php">
        <h1 class="create-title">Gestión de Preguntas</h1>
        <label for="categoria">Categoría:</label>
        <input type="text" id="categoria" name="categoria" class="name_input"><br><br>

        <label for="pregunta">Pregunta:</label>
        <input type="text" id="pregunta" name="pregunta" class="name_input"><br><br>

        <label for="respuesta">Respuesta:</label>
        <input type="text" id="respuesta" name="respuesta" class="name_input"><br><br>

        <!--<label for="puntaje">Puntaje:</label>
        <input type="text" id="puntaje" name="puntaje" class="name_input"><br><br>-->
        <label for="puntaje" >
            <select name="puntaje" id="puntaje" class="combo-box">
                <option value="100">100</option>
                <option value="200">200</option>
                <option value="300">300</option>
                <option value="400">400</option>
                <option value="500">500</option>
            </select>
        </label>

        <input type="submit" value="Guardar Pregunta" class="btn">
    </form>
</body>
</html>