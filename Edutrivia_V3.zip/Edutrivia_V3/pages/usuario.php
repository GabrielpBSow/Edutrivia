<?php include '../bd/conexion.php'?>

<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="../css/usuario.css">
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
</head>
<body>
    <div class="wrapper">
        <aside>
            <header>
                <?php
                session_start();
                    if (isset($_SESSION['usuario'])) {
                        echo '<h1 class="logo">Bienvenido, ' . $_SESSION['usuario'] . '!</h1>';
                    } else {
                        echo '
                            <script>
                                alert("TRAKAAA!, DEBES REGISTRARTE");
                                window.location = "../pages/registro.php";
                            </script>
                        ';
                        session_destroy();
                        die();  
                        // Redirige si la sesión no está iniciada
                        header("Location: ../pages/registro.php");
                        exit;
                    }
                ?>
                <br>
            </header>
            <nav>
                <ul class="menu">
                    <li><button id="jeopardy" class="boton-menu boton-categoria active">Jeopardy</button>
                    </li>
                    <li><button id="ahorcado" class="boton-menu boton-categoria active">Ahorcado</button>
                    </li>
                    <li><button id="volver" class="boton-menu boton-categoria active">Volver</button>
                    </li>
                    <li>
                        <a class="boton-menu boton-carrito" href="../static/cerrar_sesion.php">
                            <i class='bx bx-exit' style='color:#ffffff'  ></i> Salir
                        </a>
                    </li>
                </ul>
            </nav>
            <br>
            
        </aside>
        <main>
            <section id="jeopardy" class="contenido-seccion">
                <!-- Contenido para Jeopardy -->
            </section>
            <section id="ahorcado" class="contenido-seccion">
                <!-- Contenido para Ahorcado -->
            </section>
        </main>
    </div>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="../js/usuario.js"></script>
    <!--<script src="../js/menu2.js "></script>-->
    <footer>
        <h3 class="texto-footer">Derechos Reservados &copy; Alondra Morales & Gabriel Pérez</h3>
    </footer>
</body>
</html>
