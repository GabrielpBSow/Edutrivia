<?php
include '../bd/conexion.php';

if (!$conexion) {
    die("La conexión falló: " . mysqli_connect_error());
}

$sql = "SELECT Categoria FROM Juego";
$result = mysqli_query($conexion, $sql);

if ($result) {
    $categorias = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $categorias[] = $row["Categoria"];
    }

    mysqli_free_result($result);
    mysqli_close($conexion);

    $response = array(
        "categorias" => $categorias
    );

    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo "Error al obtener las categorías";
}
?>