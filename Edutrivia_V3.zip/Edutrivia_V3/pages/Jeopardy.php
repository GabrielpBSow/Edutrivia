<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/jeopardy.css">
    <link rel="icon" type="img/png" href="../img/LogoEdutrivia (1).png">
    <title>Jeopardy</title>
    </head>
<body>
    <div class="app">
        <header class="top-header">
            <h1>Edutrivia</h1>
            <p class="score">Score: <span class="score-count">0</span></p>
        </header>
        <div class="board">
        </div>
        <div class="card-modal">
            <div class="card-modal-inner">
                <h2 class="clue-text"></h2>
                <form autocomplete="off">
                    <input name="user-answer" type="text"/>
                    <button type="submit">PREGUNTA</button>
                </form>
                <div class="result">
                    <p class="result_success">CORRECTO</p>
                    <p class="result_fail">INCORRECTO</p>
                    <p class="result_correct-answer">
                        La respuesta correcta es: <span class="result_correct-answer-text"></span>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <script>
    class Edutrivia {
        constructor(element, options={}) {
            this.categories = [];
            this.clues = {};
            this.currentClue = null;
            this.score = 0;
            this.usedCards = 0;

            this.boardElement = element.querySelector(".board");
            this.scoreCountElement = element.querySelector(".score-count");
            this.formElement = element.querySelector("form");
            this.inputElement = element.querySelector("input[name=user-answer]");
            this.modalElement = element.querySelector(".card-modal");
            this.clueTextElement = element.querySelector(".clue-text");
            this.resultTextElement = element.querySelector(".result_correct-answer-text");
            this.successTextElement = element.querySelector(".result_success");
            this.failTextElement = element.querySelector(".result_fail");

            this.initGame();
        }

        initGame() {
            this.boardElement.addEventListener("click", event => {
                if (event.target.dataset.clueId) {
                    this.handleClueClick(event);
                }
            });
            this.formElement.addEventListener("submit", event => {
                this.handleFormSubmit(event);
            });

            this.updateScore(0);
            this.fetchCategories();
        }

        fetchCategories() {
            fetch('Obtener_Preguntas.php')
                .then(response => response.json())
                .then(data => {
                    const categoriesMap = {};

                    data.forEach(item => {
                        const clueId = `${item.Categoria}-${item.id}-${item.Puntaje}`;

                        if (!categoriesMap[item.Categoria]) {
                            categoriesMap[item.Categoria] = {
                                title: item.Categoria,
                                clues: []
                            };
                        }

                        categoriesMap[item.Categoria].clues.push(clueId);

                        this.clues[clueId] = {
                            question: item.Pregunta,
                            answer: item.Respuesta,
                            value: item.Puntaje
                        };
                    });

                    for (const category in categoriesMap) {
                        this.categories.push(categoriesMap[category]);
                        this.renderCategory(categoriesMap[category]);
                    }
                })
                .catch(error => {
                    console.error('Error al obtener las preguntas:', error);
                });
        }

        renderCategory(category) {
            let column = document.createElement("div");
            column.classList.add("column");

            let header = document.createElement("header");
            header.textContent = category.title;
            column.appendChild(header);

            const cluesByValue = {
                100: [],
                200: [],
                300: [],
                400: [],
                500: []
            };

            category.clues.forEach(clueId => {
                let clue = this.clues[clueId];
                cluesByValue[clue.value].push({ id: clueId, clue: clue });
            });

            for (let value = 100; value <= 500; value += 100) {
                let ul = document.createElement("ul");
                cluesByValue[value].forEach(clueData => {
                    let li = document.createElement("li");
                    li.innerHTML = `<button data-clue-id="${clueData.id}" class="clue-card">${value}</button>`;
                    ul.appendChild(li);
                });
                column.appendChild(ul);
            }

            this.boardElement.appendChild(column);
        }

         updateScore(change) {
               this.score += change;
               this.scoreCountElement.textContent = this.score;
         }

         handleClueClick(event) {
            var clue = this.clues[event.target.dataset.clueId];
            event.target.classList.add("used");
            this.inputElement.value = "";
            this.currentClue = clue;
            this.clueTextElement.textContent = this.currentClue.question;
            this.resultTextElement.textContent = this.currentClue.answer;
            this.modalElement.classList.remove("showing-result");
            this.modalElement.classList.add("visible");
            this.inputElement.focus();

            this.usedCards++; // Incrementa el contador de cartas utilizadas
            console.log("Tarjetas utilizadas:", this.usedCards); // Añadido para verificar el incremento
            this.checkIfAllCardsUsed(); // Verifica si se han usado todas las tarjetas después de actualizar
        }

        checkIfAllCardsUsed() {
            const totalQuestions = this.categories.reduce((acc, category) => acc + category.clues.length, 0);
            if (this.usedCards === totalQuestions) {
                console.log("Todas las tarjetas han sido utilizadas. El juego ha finalizado.");
                this.finishGame();
            }
        }

        finishGame() {
            const finalScore = this.score;
            window.location.href = `encuesta.php?puntaje=${finalScore}`;
        }

         handleFormSubmit(event) {
            event.preventDefault();
            var isCorrect = this.cleanseAnswer(this.inputElement.value) === this.cleanseAnswer(this.currentClue.answer);

            if (isCorrect) {
                this.updateScore(parseInt(this.currentClue.value));
            }

            this.revealAnswer(isCorrect);
        }

         cleanseAnswer(input="") {
               var friendlyAnswer = input.toLowerCase();
               friendlyAnswer = friendlyAnswer.replace("<i>", "");
               friendlyAnswer = friendlyAnswer.replace("</i>", "");
               friendlyAnswer = friendlyAnswer.replace(/ /g, "");
               friendlyAnswer = friendlyAnswer.replace(/"/g, "");
               friendlyAnswer = friendlyAnswer.replace(/^a /, "");
               friendlyAnswer = friendlyAnswer.replace(/^an /, "");      
               return friendlyAnswer.trim();
         }

         revealAnswer(isCorrect) {
               this.successTextElement.style.display = isCorrect ? "block" : "none";
               this.failTextElement.style.display = !isCorrect ? "block" : "none";
               this.modalElement.classList.add("showing-result");
               setTimeout(() => {
                  this.modalElement.classList.remove("visible");
               }, 3000);
         }
      }

      const game = new Edutrivia(document.querySelector(".app"), {});
    </script>
</body>
</html>