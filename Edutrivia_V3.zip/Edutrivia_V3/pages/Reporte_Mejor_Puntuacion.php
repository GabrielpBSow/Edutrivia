<?php
	include '../bd/conexion.php';
	require '../static/convertirpdf/fpdf/fpdf.php';

	class PDF extends FPDF
	{
		function Header()
		{
			$this->SetFont('Arial','B',24);
			$this->Cell(0,20,'Puntajes Mas Altos',0,1,'C');
			$this->Ln(10);
		}
		
		function Footer()
		{
			$this->SetY(-15);
			$this->SetFont('Arial','I', 8);
			$this->Cell(0,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
			$this->Ln(10);
			$this->Cell(0,10,'Autores: Alondra Morales y Gabriel Pérez',0,0,'C');
		}		
	}

	$query = "SELECT nombre, puntaje_obtenido FROM Usuarios ORDER BY puntaje_obtenido DESC"; 
	$resultado = mysqli_query($conexion, $query);

	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();
	$pdf->SetFont('Arial','',12);

	$pageWidth = $pdf->GetPageWidth();
	$cellWidth = 80;
	$xPos = ($pageWidth - $cellWidth) / 2;

	$pdf->SetX($xPos);
	$pdf->Cell($cellWidth,10,'Nombre',1,0,'C');
	$pdf->Cell($cellWidth / 2,10,'Puntaje',1,1,'C');

	while ($row = mysqli_fetch_array($resultado))
	{
		$pdf->SetX($xPos);
		$pdf->Cell($cellWidth,10,$row['nombre'],1,0,'C');
		$pdf->Cell($cellWidth / 2,10,$row['puntaje_obtenido'],1,1,'C');
	}	
	        //Autores
			$pdf->SetFont('Arial', 'B', 12);
			$pdf->Cell(0, 10, 'Autores: Alondra Morales y Gabriel Perez', 0, 1, 'C');

	$pdf->Output();
?>
