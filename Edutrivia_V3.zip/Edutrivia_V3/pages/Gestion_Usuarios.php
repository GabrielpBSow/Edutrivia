<?php include '../bd/conexion.php'?>
<?php
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];
    $rol = $_POST['rol'];
    // Clave secreta para la encriptación de contraseñas (deberías almacenarla de forma segura)
    $secretKey = "clave_secreta";
    // Algoritmo de encriptación para las contraseñas (puedes usar bcrypt, por ejemplo)
    $hashedPassword = password_hash($contraseña, PASSWORD_BCRYPT);

    $query = "INSERT INTO registro (nombre, correo, contraseña, rol) VALUES ('$nombre', '$correo', '$hashedPassword', '$rol');";

    $execute = mysqli_query($conexion, $query);

    sleep(1);
    header("Location: Usuarios.php");
    
?>