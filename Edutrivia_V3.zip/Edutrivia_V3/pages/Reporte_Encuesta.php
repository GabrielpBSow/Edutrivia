<?php
	include '../bd/conexion.php';   
    // Consulta para obtener datos de la tabla encuesta_satis
    $query = "SELECT COUNT(*) AS total_encuestas FROM encuesta_satis";
    $resultado = $conexion->query($query);

    if ($resultado->num_rows > 0) {
        $row = $resultado->fetch_assoc();
        $totalEncuestas = $row["total_encuestas"];
    } else {
        $totalEncuestas = 0;
    }
    // Obtener datos para las barras (por ejemplo, contar las opciones de las encuestas)
    $query_options = "SELECT opcion, COUNT(*) AS total_opciones FROM encuesta_satis GROUP BY opcion";
    $resultado_options = $conexion->query($query_options);

    // Tamaño máximo del gráfico de barras
    $maxBarWidth = 150;

    // Crear archivo PDF
    require '../static/convertirpdf/fpdf/fpdf.php';
    $pdf = new FPDF();
    $pdf->AddPage();

    // Título principal
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Resultados de Encuestas de Satisfaccion', 0, 1, 'C');

    // Estadísticas generales
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Estadisticas Generales', 0, 1, 'L');

    $pdf->Cell(0, 10, 'Total Encuestas: ' . $totalEncuestas, 0, 1, 'L');

    // Gráfico de barras
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Grafico de Opciones', 0, 1, 'L');

    $pdf->SetFillColor(0, 120, 255); // Color de las barras

    while ($row = $resultado_options->fetch_assoc()) {
        $opcion = $row['opcion'];
        $total_opciones = $row['total_opciones'];

        // Calcular la longitud de la barra proporcional
        $barLength = ($total_opciones / $totalEncuestas) * $maxBarWidth;

        // Dibujar la barra proporcional al número de opciones
        $pdf->Cell(30, 10, $opcion, 0, 0, 'C');
        $pdf->Cell($barLength, 10, '', 1, 1, 'C', true); // Representar el total con barras proporcionales
    }
        //Autores
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Autores: Alondra Morales y Gabriel Perez', 0, 1, 'C');

    $pdf->Output();
?>