document.addEventListener('DOMContentLoaded', function () {
    const menuItems = document.getElementById('menuItems');
    const gestionarUsuarios = document.getElementById('gestionarUsuarios');
    const verUsuarios = document.getElementById('verUsuarios');
    const gestionarPreguntas = document.getElementById('gestionarPreguntas');
    const verPreguntas = document.getElementById('verPreguntas');
    const reportes = document.getElementById('reportes');
    const jeopardy = document.getElementById('jeopardy');
    const ahorcado = document.getElementById('ahorcado');
    const Respaldo_BD = document.getElementById('Respaldo_BD');
    const botonVolver = document.getElementById('volver');

    const botonGestionarUsuarios = document.getElementById('GestionUsuarios');
    const botonVerUsuarios = document.getElementById('verUsuarios');
    const botonGestionarPreguntas = document.getElementById('GestionPreguntas');
    const botonVerPreguntas = document.getElementById('verPreguntas');
    const botonReportes = document.getElementById('reportes');
    const botonJeopardy = document.getElementById('jeopardy');
    const botonAhorcado = document.getElementById('ahorcado');
    const botonRespaldoBD = document.getElementById('Respaldo_BD');

    botonGestionarUsuarios.addEventListener('click', () => {
        console.log('Click en Gestionar Usuarios');
        mostrarSeccion(gestionarUsuarios, 'Gestion_Usuarios.php');
    });
    botonVerUsuarios.addEventListener('click', () => {
        console.log('Click en Ver Usuarios');
        mostrarSeccion(verUsuarios, 'VerUsuarios.php');
    });
    botonGestionarPreguntas.addEventListener('click', () => {
        console.log('Click en Gestionar Preguntas');
        mostrarSeccion(gestionarPreguntas, 'create.php');
    });
    botonVerPreguntas.addEventListener('click', () => {
        console.log('Click en Ver Preguntas');
        mostrarSeccion(verPreguntas, 'read.php');
    });
    botonReportes.addEventListener('click', () => {
        console.log('Click en Reportes');
        mostrarSeccion(reportes, 'Reportes.php');
    });
    botonJeopardy.addEventListener('click', () => {
        console.log('Click en Jeopardy');
        mostrarSeccion(jeopardy, 'jeopardy.php');
    });
    botonAhorcado.addEventListener('click', () => {
        console.log('Click en Ahorcado');
        mostrarSeccion(ahorcado, 'ahorcado.php');
    });
    botonRespaldoBD.addEventListener('click', () => {
        console.log('Click en Respaldo de Base de Datos');
        mostrarSeccion(Respaldo_BD, 'Respaldo_BD.php');
    });
    botonVolver.addEventListener('click', () => {
        console.log('Click en Volver');
        volverAdmin();
    });

    function mostrarSeccion(seccion, contenido) {
        console.log("Mostrar sección:", seccion.id, "Contenido:", contenido);
    
        const secciones = [gestionarUsuarios, verUsuarios, gestionarPreguntas, verPreguntas, reportes, jeopardy, ahorcado, Respaldo_BD];
        secciones.forEach(s => {
            if (s === seccion || s === botonVolver) {
                s.style.display = 'block';
            } else {
                s.style.display = 'none';
            }
        });
    
        seccion.innerHTML = `<iframe src="${contenido}" width="1200px" height="800px" frameborder="0"></iframe>`;
    }

    function volverAdmin() {
        console.log('Click en Volver (función volverAdmin)');
        window.location = 'admin_A.php'; // Redirige al archivo admin.php
    }
});



