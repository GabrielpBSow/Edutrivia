document.addEventListener('DOMContentLoaded', function () {
    const jeopardy = document.getElementById('jeopardy');
    const ahorcado = document.getElementById('ahorcado');
    const botonVolver = document.getElementById('volver');

    const botonJeopardy = document.getElementById('jeopardy');
    const botonAhorcado = document.getElementById('ahorcado');

    botonJeopardy.addEventListener('click', () => mostrarSeccion(jeopardy, 'jeopardy.php'));
    botonAhorcado.addEventListener('click', () => mostrarSeccion(ahorcado, 'ahorcado.php'));
    botonVolver.addEventListener('click', volverAdmin);

    function mostrarSeccion(seccion, contenido) {
        const secciones = [jeopardy, ahorcado];
        secciones.forEach(s => s.style.display = 'none');
        seccion.style.display = 'block';

        seccion.innerHTML = `<iframe src="${contenido}" width="1100px" height="700px" frameborder="0"></iframe>`;
    }
    function volverAdmin() {
        window.location = 'usuario.php'; // Redirige al archivo admin.php
    }
});

