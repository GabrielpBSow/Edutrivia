document.addEventListener('DOMContentLoaded', function () {
    const menuItems = document.getElementById('menuItems');
    const jeopardy = document.getElementById('jeopardy');
    const ahorcado = document.getElementById('ahorcado');
    const botonVolver = document.getElementById('volver');

    const botonJeopardy = document.getElementById('jeopardy');
    const botonAhorcado = document.getElementById('ahorcado');

    botonJeopardy.addEventListener('click', () => {
        console.log('Click en Jeopardy');
        mostrarSeccion(jeopardy, 'jeopardy.php');
    });
    botonAhorcado.addEventListener('click', () => {
        console.log('Click en Ahorcado');
        mostrarSeccion(ahorcado, 'ahorcado.php');
    });
    botonVolver.addEventListener('click', () => {
        console.log('Click en Volver');
        volverAdmin();
    });

    function mostrarSeccion(seccion, contenido) {
        console.log("Mostrar sección:", seccion.id, "Contenido:", contenido);
    
        const secciones = [jeopardy, ahorcado];
        secciones.forEach(s => {
            if (s === seccion || s === botonVolver) {
                s.style.display = 'block';
            } else {
                s.style.display = 'none';
            }
        });
    
        seccion.innerHTML = `<iframe src="${contenido}" width="1200px" height="800px" frameborder="0"></iframe>`;
    }

    function volverAdmin() {
        console.log('Click en Volver (función volverAdmin)');
        window.location = 'admin_E.php'; // Redirige al archivo admin.php
    }
});
