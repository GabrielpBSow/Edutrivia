var expreNomyApe =/^[a-zA-ZÀ-ÿ\s]{1,40}$/;
var expreDir =/^[a-zA-Z0-9À-ÿ\s]{1,40}$/;
var expreTel =/^\d{7,14}$/;
var expreEmail =/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
var expreCome =/^[a-zA-ZÀ-ÿ\s]{1,40}$/;

function validacion(){
    if(document.frm1.Nombre.value.length==0 || !expreNomyApe.test(document.frm1.Nombre.value)){
        document.getElementById("Nombre").focus();
        return false;
    }
    if(document.frm1.Correo.value.length==0 || !expreEmail.test(document.frm1.Correo.value)){
        document.getElementById("Correo").focus();
        return false;
    }
    if(document.frm1.Contraseña.value.length==0){
        document.getElementById("Contraseña").focus();
        return false;
    }
    frm1.submit();
}
