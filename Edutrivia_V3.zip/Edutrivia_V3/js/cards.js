//CARTAS

const card{
    {
        titulo: "Juego_1";
        categoria:{
            nombre: "Java";
            id: "preguntas";
        }
    }
}