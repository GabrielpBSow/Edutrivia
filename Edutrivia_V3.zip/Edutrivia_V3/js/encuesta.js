let selectedOption = 0;

function selectOption(option) {
    selectedOption = option;
    document.querySelectorAll('.option').forEach((el, index) => {
    el.style.border = index + 1 === selectedOption ? '2px solid #333' : 'none';
    });
}

function submitForm() {
    $.ajax({
        type: 'POST',
        url: 'guardaEncuesta.php',
        data: { opcion: selectedOption },
        success: function(response) {
            console.log(response);
        },
        error: function(error) {
            console.error(error);
        }
    });
}
